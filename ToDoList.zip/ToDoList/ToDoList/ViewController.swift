//
//  ViewController.swift
//  ToDoList
//
//  Created by Zeynia Wax on 2022/08/22.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    

    @IBOutlet weak var tableViewContainer: UITableView!
    
    var Activities:[NSManagedObject] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    
        title = "To Do  List"
         tableViewContainer.register(UITableViewCell.self,
                            forCellReuseIdentifier: "Cell")
    }
    
    override func viewWillAppear(_ animated: Bool){
        super.viewWillAppear(animated)
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{
            return
        }
        let managedContext =
        appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Items")
        
        do {
            Activities = try managedContext.fetch(fetchRequest)
        } catch let error as NSError {
            print("could not fetch. \(error),\(error.userInfo)")
        }
    }

   
    @IBAction func AddActivities(_ sender: Any) {
        let alert = UIAlertController(title:"New Activity",
                                       message: "Add your goal for the day",
                                       preferredStyle: .alert)
         
         let saveAction = UIAlertAction(title: "Save",
                                        style: .default) {
           [unowned self] action in
                                         
           guard let textField = alert.textFields?.first,
             let activityToSave = textField.text else {
               return
           }
           
             self.save(toDoActivity: activityToSave)
           self.tableViewContainer.reloadData()
         }
         
         let cancelAction = UIAlertAction(title: "Cancel",
                                          style: .cancel)
         
         alert.addTextField()
         
         alert.addAction(saveAction)
         alert.addAction(cancelAction)
         
         present(alert, animated: true)
    }
    
    func save(toDoActivity: String){
        guard let appsDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        let managedContext = appsDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Items", in: managedContext)!
        let items = NSManagedObject(entity: entity, insertInto: managedContext)
        items.setValue(toDoActivity, forKey: "toDoActivity")
        
        do {
            try managedContext.save()
            Activities.append(items)
        }catch let error as NSError{
            print("Could not save.\(error), \(error.userInfo)")
        }
            
    }
}

extension ViewController: UITableViewDataSource {
  
  func tableView(_ tableView: UITableView,
                 numberOfRowsInSection section: Int) -> Int {
    return Activities.count
  }
  
  func tableView(_ tableView: UITableView,
                 cellForRowAt indexPath: IndexPath)
                 -> UITableViewCell {
    let items = Activities[indexPath.row]
    let cell =
      tableView.dequeueReusableCell(withIdentifier: "Cell",
                                    for: indexPath)
                     cell.textLabel?.text = items.value(forKeyPath: "toDoActivity") as? String
                     return cell
  }
}


